const functions = require('firebase-functions');
const admin = require('firebase-admin');
const Stripe = require('stripe');
const cors = require('cors');

// Initialize Firebase Admin
admin.initializeApp();

// Initialize Stripe with secret key
const stripe = new Stripe(functions.config().stripe.secret_key, {
  apiVersion: '2023-10-16',
});

// CORS configuration
const corsHandler = cors({ origin: true });

// Subscription limits by tier
const getSubscriptionLimits = (tier) => {
  switch (tier) {
    case 'free':
      return {
        maxDecks: 3,
        maxCardsPerDeck: 100,
        hasOfflineMode: false,
        hasAdvancedAnalytics: false,
        hasCustomDecks: false,
        hasDataExport: false,
        hasAIFeatures: false,
        hasPrioritySupport: false,
        hasAdvancedStatistics: false,
      };
    case 'premium':
      return {
        maxDecks: -1, // Unlimited
        maxCardsPerDeck: -1,
        hasOfflineMode: true,
        hasAdvancedAnalytics: true,
        hasCustomDecks: true,
        hasDataExport: true,
        hasAIFeatures: true,
        hasPrioritySupport: true,
        hasAdvancedStatistics: true,
      };
    default:
      return getSubscriptionLimits('free');
  }
};

// Create Stripe checkout session
exports.createCheckoutSession = functions.https.onRequest((req, res) => {
  return corsHandler(req, res, async () => {
    if (req.method !== 'POST') {
      res.status(405).send('Method Not Allowed');
      return;
    }

    try {
      const { userId, priceId, tier, successUrl, cancelUrl } = req.body;

      if (!userId || !priceId || !tier || !successUrl || !cancelUrl) {
        res.status(400).send('Missing required parameters');
        return;
      }

      // Get or create Stripe customer
      const userDoc = await admin.firestore().collection('users').doc(userId).get();
      const userData = userDoc.data();
      
      let customerId = userData?.subscription?.stripeCustomerId;

      if (!customerId) {
        // Create new Stripe customer
        const customer = await stripe.customers.create({
          email: userData?.email,
          metadata: {
            firebaseUID: userId,
          },
        });
        customerId = customer.id;

        // Update user with customer ID
        await admin.firestore().collection('users').doc(userId).update({
          'subscription.stripeCustomerId': customerId,
        });
      }

      // Create checkout session
      const session = await stripe.checkout.sessions.create({
        customer: customerId,
        payment_method_types: ['card'],
        line_items: [
          {
            price: priceId,
            quantity: 1,
          },
        ],
        mode: 'subscription',
        success_url: successUrl,
        cancel_url: cancelUrl,
        metadata: {
          userId,
          tier,
        },
        subscription_data: {
          trial_period_days: 14, // 14-day free trial
          metadata: {
            userId,
            tier,
          },
        },
      });

      res.json({ sessionId: session.id });
    } catch (error) {
      console.error('Error creating checkout session:', error);
      res.status(500).send('Internal Server Error');
    }
  });
});

// Create customer portal session
exports.createPortalSession = functions.https.onRequest((req, res) => {
  return corsHandler(req, res, async () => {
    if (req.method !== 'POST') {
      res.status(405).send('Method Not Allowed');
      return;
    }

    try {
      const { userId, returnUrl } = req.body;

      if (!userId || !returnUrl) {
        res.status(400).send('Missing required parameters');
        return;
      }

      // Get user's Stripe customer ID
      const userDoc = await admin.firestore().collection('users').doc(userId).get();
      const userData = userDoc.data();
      const customerId = userData?.subscription?.stripeCustomerId;

      if (!customerId) {
        res.status(400).send('No Stripe customer found');
        return;
      }

      // Create portal session
      const session = await stripe.billingPortal.sessions.create({
        customer: customerId,
        return_url: returnUrl,
      });

      res.json({ url: session.url });
    } catch (error) {
      console.error('Error creating portal session:', error);
      res.status(500).send('Internal Server Error');
    }
  });
});

// Stripe webhook handler
exports.stripeWebhook = functions.https.onRequest(async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const endpointSecret = functions.config().stripe.webhook_secret;

  let event;

  try {
    event = stripe.webhooks.constructEvent(req.rawBody, sig, endpointSecret);
  } catch (err) {
    console.error('Webhook signature verification failed:', err);
    res.status(400).send('Webhook Error');
    return;
  }

  try {
    switch (event.type) {
      case 'customer.subscription.created':
      case 'customer.subscription.updated':
        await handleSubscriptionChange(event.data.object);
        break;
      
      case 'customer.subscription.deleted':
        await handleSubscriptionCancellation(event.data.object);
        break;
      
      case 'invoice.payment_succeeded':
        await handlePaymentSucceeded(event.data.object);
        break;
      
      case 'invoice.payment_failed':
        await handlePaymentFailed(event.data.object);
        break;
      
      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    res.json({ received: true });
  } catch (error) {
    console.error('Error processing webhook:', error);
    res.status(500).send('Webhook Error');
  }
});

// Handle subscription changes
async function handleSubscriptionChange(subscription) {
  const userId = subscription.metadata.userId;
  const tier = subscription.metadata.tier;

  if (!userId || !tier) {
    console.error('Missing userId or tier in subscription metadata');
    return;
  }

  const subscriptionData = {
    status: subscription.status,
    tier,
    stripeCustomerId: subscription.customer,
    stripeSubscriptionId: subscription.id,
    currentPeriodStart: admin.firestore.Timestamp.fromDate(new Date(subscription.current_period_start * 1000)),
    currentPeriodEnd: admin.firestore.Timestamp.fromDate(new Date(subscription.current_period_end * 1000)),
    cancelAtPeriodEnd: subscription.cancel_at_period_end,
    trialEnd: subscription.trial_end ? admin.firestore.Timestamp.fromDate(new Date(subscription.trial_end * 1000)) : null,
    limits: getSubscriptionLimits(tier),
  };

  await admin.firestore().collection('users').doc(userId).update({
    subscription: subscriptionData,
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  console.log(`Updated subscription for user ${userId} to ${tier}`);
}

// Handle subscription cancellation
async function handleSubscriptionCancellation(subscription) {
  const userId = subscription.metadata.userId;

  if (!userId) {
    console.error('Missing userId in subscription metadata');
    return;
  }

  const subscriptionData = {
    status: 'canceled',
    tier: 'free',
    limits: getSubscriptionLimits('free'),
  };

  await admin.firestore().collection('users').doc(userId).update({
    subscription: subscriptionData,
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  console.log(`Cancelled subscription for user ${userId}`);
}

// Handle successful payment
async function handlePaymentSucceeded(invoice) {
  if (invoice.subscription) {
    const subscription = await stripe.subscriptions.retrieve(invoice.subscription);
    await handleSubscriptionChange(subscription);
  }
}

// Handle failed payment
async function handlePaymentFailed(invoice) {
  const customerId = invoice.customer;
  
  // Find user by customer ID
  const usersQuery = await admin.firestore()
    .collection('users')
    .where('subscription.stripeCustomerId', '==', customerId)
    .limit(1)
    .get();

  if (!usersQuery.empty) {
    const userDoc = usersQuery.docs[0];
    await userDoc.ref.update({
      'subscription.status': 'past_due',
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    console.log(`Payment failed for user ${userDoc.id}`);
  }
}

// Get subscription status (for debugging)
exports.getSubscriptionStatus = functions.https.onRequest((req, res) => {
  return corsHandler(req, res, async () => {
    if (req.method !== 'POST') {
      res.status(405).send('Method Not Allowed');
      return;
    }

    try {
      const { userId } = req.body;

      if (!userId) {
        res.status(400).send('Missing userId parameter');
        return;
      }

      const userDoc = await admin.firestore().collection('users').doc(userId).get();
      const userData = userDoc.data();
      const subscription = userData?.subscription;

      res.json({ subscription });
    } catch (error) {
      console.error('Error getting subscription status:', error);
      res.status(500).send('Internal Server Error');
    }
  });
});
